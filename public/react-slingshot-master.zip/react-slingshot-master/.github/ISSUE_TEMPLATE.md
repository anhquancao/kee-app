Node version:

npm version:

Operating system:

Command line used:

Steps to reproduce:
